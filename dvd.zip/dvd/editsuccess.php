<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
        <?php
            require 'conn.php';
            $sql_update ="UPDATE member SET name ='$_POST[name]',address='$_POST[address]',telephone='$_POST[telephone]' WHERE id ='$_POST[id]' ";

            $result= $conn->query($sql_update);

            if(!$result) {
            die("Error God Damn it : ". $conn->error);
            } else {

            echo "Edit Success <br>";
            header("refresh: 1; url=http://localhost/dvd/mainmenu.php");
            }

        ?>

    
</body>
</html>